package LDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import LDTO.LDTO;

public class LDAO {
	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;
	int cnt = 0;

	public void getConn() {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String db_url = "jdbc:oracle:thin:@localhost:1521:xe";
			String db_id = "hr";
			String db_pw = "hr";
			conn = DriverManager.getConnection(db_url, db_id, db_pw);
			
		} catch (Exception e) {
			e.printStackTrace();
		}

		
	}
	
	public void close() {
		try {
			if (rs != null) {
				rs.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int save(String id, String code, String singer, String title, String x, String y, String emotion) {
		
		
		try {
			getConn();
			
			String sql = "insert into testcode values(TO_CHAR(SYSDATE, 'YYYY-MM-DD'),?,?,?,?,?,?,?)";
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id);
			psmt.setString(2,code );
			psmt.setString(3, singer);
			psmt.setString(4, title);
			psmt.setString(5, x);
			psmt.setString(6, y);
			psmt.setString(7, emotion);
			
			cnt = psmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close();
		}
		
		return cnt;
	}

	public ArrayList<LDTO> load(String day,String id) {
		
		ArrayList<LDTO> list = new ArrayList<LDTO>();
		
		
		try {
			getConn();
			
			String sql = "select *  from testcode where id=? and day =?";
			
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1, id);
			psmt.setString(2, day);
			
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				
				String get_day = rs.getString(1);
				String get_id = rs.getString(2);
				String get_code = rs.getString(3);
				String get_singer = rs.getString(4);
				String get_title = rs.getString(5);
				String get_x = rs.getString(6);
				String get_y = rs.getString(7);
				String get_emotion = rs.getString(8);
				
				LDTO dto = new LDTO(get_day, get_id, get_code, get_singer, get_title, get_x, get_y, get_emotion);
				
				list.add(dto);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close();
		}
		
		
		return list;
		
	}

	public ArrayList<String> load_day(String id){
		
		ArrayList<String> list = new ArrayList<String>();
		
		try {
			getConn();
			
			String sql = "select distinct TO_CHAR(day,'YYYY-MM-DD') as day from testcode where id=?";
			
			psmt = conn.prepareStatement(sql);
			
			psmt.setString(1,id);
			
			rs  = psmt.executeQuery();
			
			while(rs.next()) {
				String day = rs.getString(1);
				list.add(day);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			close();
		}
		
		return list;
	}

}
