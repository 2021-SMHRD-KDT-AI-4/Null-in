package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import LDAO.LDAO;

@WebServlet("/recieve_data")
public class recieve_data extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("euc-kr");

		response.setCharacterEncoding("euc-kr");

		PrintWriter out = response.getWriter();
		String[] title = request.getParameter("title").split("/");
		String[] singer = request.getParameter("singer").split("/");
		
		String[] emotion = request.getParameter("emotion").split("/");
		
		String[] code = request.getParameter("code").split("/");
		

		int cnt = 0;
//		out.print("<html>");
//		out.print("<body>");
//		for (int i = 0; i < title.length; i++) {			
//			out.print("<p>�뷡 ���� : "+title[i] +"<br>�����̸�: "+singer[i]);
//			out.print("<br> ���� : "+emotion[i]);
//			out.print("</p>");
//			out.print("<div style='height:50px; width:50px; background-color:#"+code[i]+"' ;'>");
//			out.print("</div>");
//		}
//		out.print("</body>");
//		out.print("</html>");

		// ��ǥ
		HttpSession session = request.getSession();
		DTO.MemDTO info = (DTO.MemDTO) session.getAttribute("info");
		String id = info.getId();

		// ���� ����
		ArrayList<String> elist = new ArrayList<String>();
		if (emotion != null) {
			for (int i = 0; i < emotion.length; i++) {
				if (emotion[i].equals("1")) {
					elist.add("�г�");
				} else if (emotion[i].equals("2")) {
					elist.add("��ſ�");
				} else if (emotion[i].equals("3")) {
					elist.add("�ູ");
				} else if (emotion[i].equals("4")) {
					elist.add("����");
				} else if (emotion[i].equals("5")) {
					elist.add("�Ҿ�");
				} else if (emotion[i].equals("7")) {
					elist.add("���");
				} else if (emotion[i].equals("6")) {
					elist.add("���");
				}
			}
		}
		String b = "";
		// ��ǥ �̱�
		System.out.println(code.length);
		
		String[] x = new String[code.length];
		String[] y = new String[code.length];

		for (int k = 0; k < code.length; k++) {

			String[] ca = code[k].split("");
			
			for (int i = 0; i < ca.length; i++) {
				if (ca[i].equals("A") || ca[i].equals("a") || ca[i].equals("1")) {
					b += "1";
				} else if (ca[i].equals("B") || ca[i].equals("b") || ca[i].equals("2")) {
					b += "2";
				} else if (ca[i].equals("C") || ca[i].equals("c") || ca[i].equals("3")) {
					b += "3";
				} else if (ca[i].equals("D") || ca[i].equals("d") || ca[i].equals("4")) {
					b += "4";
				} else if (ca[i].equals("E") || ca[i].equals("e") || ca[i].equals("5")) {
					b += "5";
				} else if (ca[i].equals("F") || ca[i].equals("f") || ca[i].equals("6")) {
					b += "6";
				}else if ( ca[i].equals("7")) {
					b += "7";
				}else if ( ca[i].equals("8")) {
					b += "8";
				}else if (ca[i].equals("9")) {
					b += "9";
				}else if (ca[i].equals("0")) {
					b += "0";
				}
			}
			System.out.println(b);

			String[] xy = b.split("");
			

			x[k] = xy[0] + xy[1] + xy[2];
			y[k] = xy[3] + xy[4] + xy[5];
		}

		int cnt1 = 0;

		LDAO dao = new LDAO();

		/*
		 * System.out.println(id); System.out.println(code[0]);
		 * System.out.println(singer[0]); System.out.println(title[0]);
		 * System.out.println(x); System.out.println(y);
		 * System.out.println(elist.get(0));
		 */

		// cnt1=dao.save(id,code[0],singer[0],title[0],x,y,elist.get(0));

		for (int i = 0; i < title.length; i++) {
			if (elist.get(i) != null) {
				cnt1 = dao.save(id, code[i], singer[i], title[i], x[i], y[i], elist.get(i));
			} else {
				cnt1 = dao.save(id, code[i], singer[i], title[i], x[i], y[i], "");
			}
			System.out.println(cnt1);
		}

		if (cnt1 > 0) {
			response.sendRedirect("main.jsp");
		}

	}

}
