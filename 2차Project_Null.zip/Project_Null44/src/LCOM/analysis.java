package LCOM;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/analysis")
public class analysis extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("euc-kr");
		
		String[] title = request.getParameterValues("title");
		String[] singer = request.getParameterValues("singer");
		
		for (int i = 0; i < singer.length; i++) {
			System.out.println(title[i]+"/"+singer[i]);
		}
		
		ArrayList<String[]> list = new ArrayList<String[]>();
				
		list.add(title);
		list.add(singer);
				
		HttpSession session = request.getSession();
		session.setAttribute("list", session);
		
		response.sendRedirect("main.jsp#analysis");
		
		
	}

}
