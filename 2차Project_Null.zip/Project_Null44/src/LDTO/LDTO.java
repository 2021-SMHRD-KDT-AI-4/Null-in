package LDTO;

public class LDTO {

	private String day;
	private String id;
	private String code;
	private String singer;
	private String title;
	private String x;
	private String y;
	private String emotion;
	
	public LDTO(String day, String id, String code, String singer, String title, String x, String y, String emotion) {
		this.day = day;
		this.id = id;
		this.code = code;
		this.singer = singer;
		this.title = title;
		this.x = x;
		this.y = y;
		this.emotion = emotion;
	}

	public LDTO(String x, String y) {
		super();
		this.x = x;
		this.y = y;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSinger() {
		return singer;
	}

	public void setSinger(String singer) {
		this.singer = singer;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}

	public String getY() {
		return y;
	}

	public void setY(String y) {
		this.y = y;
	}

	public String getEmotion() {
		return emotion;
	}

	public void setEmotion(String emotion) {
		this.emotion = emotion;
	}
	
	
	
	
	
	
}
