CREATE TABLE SYS_MEMBER(
	ID	VARCHAR2(100) NOT NULL PRIMARY KEY,
	PW	VARCHAR2(100) NOT NULL,
	EMAIL	VARCHAR2(100) NOT NULL,
	PHONE	VARCHAR2(100) NOT NULL,
	NAME	VARCHAR2(100) NOT NULL,
	GENDER	VARCHAR2(100) NOT NULL
);

INSERT INTO SYS_MEMBER VALUES(
	'admin', '1234', 'abc@abc.com',
	'011-2345-6789', 'ȫ�浿', 'male'
);

SELECT * FROM SYS_MEMBER;
SELECT * FROM testcode;

DROP TABLE testcode;

CREATE TABLE testcode(
	day date,
	ID	VARCHAR2(100) NOT NULL,	
	code	VARCHAR2(100) NOT NULL,
	singer	VARCHAR2(100) NOT NULL,
	title	VARCHAR2(100) NOT NULL,
	x	VARCHAR2(100) NOT NULL,
	y	VARCHAR2(100) NOT NULL,
	emotion varchar2(100)
);

select distinct TO_CHAR(day,'YYYY-MM-DD') from testcode;


insert into testcode values(TO_CHAR('2021-06-21', 'YYYY-MM-DD'),'admin','49A631','������','���϶�','444','444','���');
insert into testcode values('2021-06-21','admin','7834A1','�̹���','��ʹ��','783','411','����');
insert into testcode values('2021-06-21', 'admin','FF7756','����','Come and kiss','667','756','��ſ�');
insert into testcode values('2021-06-21', 'admin','80379D','�Ѱ���','�����Ϸ�','803','794','�ູ');
insert into testcode values('2021-06-21', 'admin','AA3339','�̵���','�����ٷ�','113','339','�г�');
insert into testcode values('2021-06-21', 'admin','374262','�Ź̵�','�λ��� �� �����ʾ�','374','262','���');
insert into testcode values('2021-06-21', 'admin','92407A','ì��Ÿ','Notihng at All','924','071','����');
insert into testcode values('2021-06-21', 'admin','5575AB','ä��','Work','557','512','�Ҿ�');

select * from testcode where day='2021-06-21';
delete testcode where singer = '������';
update TESTCODE set x='491', y='631' where singer='������';
update TESTCODE set x='804', y='872' where singer='�漭';

CREATE TABLE matching(
	
		
	
	singer	VARCHAR2(100) NOT NULL,
	title	VARCHAR2(100) NOT NULL,
	x	VARCHAR2(100) NOT NULL,
	y	VARCHAR2(100) NOT NULL,
	emotion varchar2(100)
);








DROP TABLE SYS_MEMBER;